Adobe Commerce和Magento Open Source使用依赖性注入来取代Magento 1.x中Mage类提供的功能。

它允许对象A去声明它的依赖为一个外部的对象B。A声明的依赖关系通常是类接口，B提供的依赖关系是这些接口的具体实现。

这种设计的代码是松耦合的，因为对象A不再需要关注它自己的依赖关系的初始化。对象B根据配置或期望的行为来决定向对象A提供哪些实现。

对于扩展开发者来说，这是一个需要理解的重要概念，因为它是Adobe Commerce和Magento Open Source如何构建类的基础。