在web应用程序中，路由是将URL请求中的数据提供给适当的类进行处理的行为。Magento路由使用以下流程：

pub/index.php => Application => Front controller => Routing => Controller Action.



### FrontController class

FrontCntroller类通过RouterList类提供的路由列表进行搜索，直到匹配到一个可以处理请求的路由。当FrontController找到一个匹配的路由时，它将请求分派给路由返回的一个动作类。

如果FrontController不能找到处理请求的路由，它就使用默认的路由。



### Router class

路由类将一个请求与处理该请求的Action类相匹配。下面的表格显示了Magento自带的核心路由。

前端路由：

- robots：将请求与rebots.txt文件匹配
- urlrewrite：将请求与数据库中定义的URL匹配
- standard：标准路由
- cms：匹配对CMS页面的请求
- default：默认路由

adminhtml路由：

- admin：匹配Admin请求
- default：Admin的默认路由



#### Standard router

一个使用标准路由的url拥有下面格式：

```
<store-url>/<store-code>/<front-name>/<controller-name>/<action-name>
```

- store-url：指定应用实例的基础地址
- store-code：指定store上下文
- front-name：指定FrontController会使用的frontName，比如[routesxml]
- controller-name: 指定控制器名
- action-name：指定在控制器类上执行的action类

标准路由会解析此URL格式，并将其与正确的控制器和Action相匹配。



#### Default router

DefaultRouter类，是应用在路由检查过程中的最后一个路由。到达这一端的请求通常包含以前的路由器无法处理的无效URL。

应用使用默认的NoRouteHandler去处理这些请求，但是你也可以通过实现NoRouteHandlerInterface去重写自己的no-route-handler。



#### Custom routers

通过创建一个RouterInterface实现来创建一个自定义路由，同时在这个类中定义match()函数去使用你自己的路由匹配逻辑。

如果你需要路由配置数据，可以使用Route Config类。

去添加你的自定义路由到FrontController的路由列表中，在你的模块的frontend/di.xml文件中添加以下信息：

```xml
<type name="Magento\Framework\App\RouterList">
    <arguments>
        <argument name="routerList" xsi:type="array">
            <item name="%name%" xsi:type="array">
                <item name="class" xsi:type="string">%classpath%</item>
                <item name="disable" xsi:type="boolean">false</item>
                <item name="sortOrder" xsi:type="string">%sortorder%</item>
            </item>
        </argument>
    </arguments>
</type>
```

- %name% - 在Magento的唯一路由名
- %classpath% - 路由类的地址。例如: Magento\Robots\Controller\Router
- %sortorder% - 该实体在路由列表中的排序顺序。



### routes.xml

routes.xml文件映射出哪一个模块需要使用特定的frontName和区域的URL。routes.xml文件在模块中的位置（etc/frontend或etc/adminhtml）指定了哪些路由是激活的。

该文件内容使用了如下格式：

```xml
<config xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:noNamespaceSchemaLocation="urn:magento:framework:App/etc/routes.xsd">
    <router id="%routerId%">
        <route id="%routeId%" frontName="%frontName%">
            <module name="%moduleName%"/>
        </route>
    </router>
</config>
```

- %routerId - 指定在Magento的路由名。可以看Router class章节的参考表。
- %routeId% - 为该路由指定唯一的节点id，也是其关联的布局处理xml文件名的第一段（routeId_controller_action.xml）
- %frontName% - 指定了一个请求的基础URL之后的第一段。
- %mouduleName% - 指定模块名。

#### Before and after parameters

